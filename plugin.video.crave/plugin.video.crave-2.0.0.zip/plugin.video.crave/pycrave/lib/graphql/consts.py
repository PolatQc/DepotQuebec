# ===================================================================
#
#   HEADERS
#
# ===================================================================

HEADERS = {
  'accept': 'application/json',
  'accept-encoding': 'gzip',
  'connection': 'Keep-Alive',
  'content-type': 'application/json; charset=utf-8',
  'x-client-platform': 'platform_web',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
  'origin': 'https://www.crave.ca',
  'referer': 'https://www.crave.ca/',
}




# ===================================================================
#
#   RTE API CONFIG
#
# ===================================================================

RTE_GRAPHQL_URL = 'https://rte-api.bellmedia.ca/graphql'
RTE_APP_ID = 'contentid/app-crave'

_SC = {'userMaturity': 'ADULT', 'userLanguage': 'FR'}  # placeholder, overridden at request time




# ===================================================================
#
#   RTE PAYLOADS
#
# ===================================================================

GET_APP_PAYLOAD = {
  'operationName': 'GetApp',
  'variables': {
    'id': RTE_APP_ID,
    'sessionContext': _SC,
    'isNonAdminUser': False
  },
  'query': (
    'query GetApp($sessionContext: SessionContext!, $id: String!) {'
    '  app(sessionContext: $sessionContext, id: $id) {'
    '    id title'
    '    navigation {'
    '      navigationLinks {'
    '        link {'
    '          displayTitle'
    '          action { ... on Screen { id path } __typename }'
    '          __typename'
    '        }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_SCREEN_PAYLOAD = {
  'operationName': 'GetScreen',
  'variables': {
    'id': '',
    'sessionContext': _SC,
    'limit': 30
  },
  'query': (
    'query GetScreen($sessionContext: SessionContext!, $id: String!, $limit: Int, $cursor: String) {'
    '  screen(sessionContext: $sessionContext, id: $id) {'
    '    id title'
    '    navigation {'
    '      navigationLinks {'
    '        action { ... on Screen { id path } __typename }'
    '        displayTitle'
    '      }'
    '    }'
    '    screenContentsPage(limit: $limit, cursor: $cursor) {'
    '      cursor'
    '      screenContents {'
    '        __typename'
    '        ... on Container { id displayTitle style displayType }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_CONTAINER_PAYLOAD = {
  'operationName': 'GetPosterRotator',
  'variables': {
    'id': '',
    'sessionContext': _SC,
    'limit': 50
  },
  'query': (
    'query GetPosterRotator($sessionContext: SessionContext!, $id: String!, $cursor: String, $limit: Int) {'
    '  container(sessionContext: $sessionContext, id: $id) {'
    '    id displayTitle'
    '    containerItemsPage(cursor: $cursor, limit: $limit) {'
    '      cursor'
    '      items {'
    '        __typename'
    '        ... on MediaMetadata {'
    '          id path title mediaType locked shortDescription description'
    '          metadataImages { poster { url } thumbnail { url } }'
    '          originatingNetworkLogo { url }'
    '        }'
    '        ... on ContentMetadata {'
    '          id path title contentType seasonNumber episodeNumber shortDescription locked'
    '          media { id path title mediaType }'
    '          metadataImages { poster { url } thumbnail { url } }'
    '        }'
'      }'
    '    }'
    '  }'
    '}'
  )
}


GET_SEARCH_PAYLOAD = {
  'operationName': 'GetSearch',
  'variables': {
    'sessionContext': _SC,
    'searchQuery': '',
    'pageNumber': 0,
    'pageSize': 50,
  },
  'query': (
    'query GetSearch($sessionContext: SessionContext!, $searchQuery: String!, $pageNumber: Int!, $pageSize: Int!) {'
    '  search('
    '    sessionContext: $sessionContext'
    '    searchRequest: {searchQuery: $searchQuery, pageNumber: $pageNumber, pageSize: $pageSize}'
    '  ) {'
    '    pageSize hasMore found'
    '    mediaResults {'
    '      ... on MediaMetadata {'
    '        __typename id path title mediaType locked shortDescription description'
    '        metadataImages { poster { url } thumbnail { url } }'
    '        originatingNetworkLogo { url }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_SHOWPAGE_PAYLOAD = {
  'operationName': 'GetShowpage',
  'variables': {
    'sessionContext': _SC,
    'ids': []
  },
  'query': (
    'query GetShowpage($sessionContext: SessionContext!, $ids: [String!]!) {'
    '  medias(sessionContext: $sessionContext, ids: $ids) {'
    '    id path title mediaType'
    '    description'
    '    productionYear'
    '    metadataImages { poster { url } thumbnail { url } }'
    '    originatingNetworkLogo { url }'
    '    seasons { id title seasonNumber }'
    '    firstContent {'
    '      id title contentType locked'
    '      duration { timeInSecs }'
    '      languageIndicators {'
    '        indicator indicatorLabel'
    '        languages { langCode displayTitle locked }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_CONTINUE_WATCHING_PAYLOAD = {
  'operationName': 'GetContinueWatching',
  'variables': {
    'sessionContext': _SC,
    'limit': 30
  },
  'query': (
    'query GetContinueWatching($sessionContext: SessionContext!, $limit: Int, $cursor: String) {'
    '  continueWatchingItemsPage(sessionContext: $sessionContext, limit: $limit, cursor: $cursor) {'
    '    cursor'
    '    items {'
    '      id'
    '      media {'
    '        __typename id path title mediaType locked shortDescription description'
    '        metadataImages { poster { url } thumbnail { url } }'
    '        originatingNetworkLogo { url }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_MY_LIST_PAYLOAD = {
  'operationName': 'GetMyList',
  'variables': {
    'sessionContext': _SC,
    'limit': 50
  },
  'query': (
    'query GetMyList($sessionContext: SessionContext!, $limit: Int, $cursor: String) {'
    '  myListItemsPage(sessionContext: $sessionContext, limit: $limit, cursor: $cursor) {'
    '    cursor'
    '    items {'
    '      ... on MediaMetadata {'
    '        __typename id path title mediaType locked shortDescription description'
    '        metadataImages { poster { url } thumbnail { url } }'
    '        originatingNetworkLogo { url }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_LIVE_CHANNELS_PAYLOAD = {
  'operationName': 'GetChannelEventList',
  'variables': {
    'sessionContext': _SC,
    'groupId': 'AllChannels'
  },
  'query': (
    'query GetChannelEventList($sessionContext: SessionContext!, $groupId: String!) {'
    '  liveChannelGroup(sessionContext: $sessionContext, groupId: $groupId) {'
    '    groupId groupName'
    '    channels {'
    '      channelId'
    '      streamContent {'
    '        __typename id path title shortDescription locked'
    '        metadataImages { channelLogo { url } }'
    '      }'
    '      events {'
    '        tmsId eventTitle startTimeUtc endTimeUtc'
    '        eventImage { url }'
    '      }'
    '    }'
    '  }'
    '}'
  )
}


GET_BOOKMARKS_BY_SEASON_PAYLOAD = {
  'operationName': 'GetBookmarksBySeasonIdPage',
  'variables': {
    'sessionContext': _SC,
    'id': '',
    'contentFormat': {'format': 'LONGFORM'},
    'limit': 30
  },
  'query': (
    'query GetBookmarksBySeasonIdPage($sessionContext: SessionContext!, $id: String!, $contentFormat: ContentFormatRequest, $cursor: String, $limit: Int) {'
    '  bookmarksBySeasonIdItemsPage(sessionContext: $sessionContext, id: $id, contentFormat: $contentFormat, cursor: $cursor, limit: $limit) {'
    '    cursor'
    '    bookmarks {'
    '      contentId'
    '      progressPercentage'
    '    }'
    '  }'
    '}'
  )
}


GET_SEASON_PAYLOAD = {
  'operationName': 'GetContentBySeasonId',
  'variables': {
    'sessionContext': _SC,
    'id': '',
    'contentFormat': None
  },
  'query': (
    'query GetContentBySeasonId($sessionContext: SessionContext!, $id: String!, $contentFormat: ContentFormatRequest) {'
    '  contentsBySeasonId(sessionContext: $sessionContext, id: $id, contentFormat: $contentFormat) {'
    '    id path title episodeNumber locked'
    '    shortDescription'
    '    broadcastDate'
    '    duration { timeInSecs }'
    '    metadataImages { thumbnail { url } poster { url } }'
    '    languageIndicators {'
    '      indicator indicatorLabel'
    '      languages { langCode displayTitle locked }'
    '    }'
    '  }'
    '}'
  )
}
