# -*- coding: utf-8 -*-
# version 4.0.0 - Compatible Kodi 21 (Python 3)

import xbmcaddon, xbmc

def log(msg):
    """ Envoie un message dans le journal (log) de Kodi si le mode Debug est activé """
    addon = xbmcaddon.Addon()
    if addon.getSetting('DebugMode') == 'true':
        # On force la conversion en string pour éviter les plantages Python 3
        # et on utilise xbmc.LOGINFO pour s'assurer que c'est visible
        xbmc.log('[ Tele-Quebec ]: ' + str(msg), xbmc.LOGINFO)