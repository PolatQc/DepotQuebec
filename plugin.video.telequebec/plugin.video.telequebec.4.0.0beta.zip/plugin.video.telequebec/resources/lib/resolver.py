import requests
import xbmc

def get_m3u8_url(media_id):
    # Données extraites de tes outils de développement
    account_id = "6150020952001"
    policy_key = "BCpkADawqM1zT80XdwnKnEWM7cZxQ0ehabhE7vwk1uGvadu6uwhHHKu8PVdzlovnaDmkJh5bGM5Ba4hRdK3G5WI9QWhwIYLx0ycOozAJ3l-ZHxOO1KPbgYsaOlzjNPUpsadfxCDQfYd5eP2X4QnFbC5UgzvFZIPTnTayDw"
    
    # URL de l'API Brightcove (Playback API)
    url = f"https://edge.api.brightcove.com/playback/v1/accounts/{account_id}/videos/ref:{media_id}"
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Accept": f"application/json;pk={policy_key}",
        "Origin": "https://telequebec.tv",
        "Referer": "https://telequebec.tv/"
    }

    try:
        xbmc.log(f"TQ_DEBUG: Appel Brightcove pour l'ID {media_id}", xbmc.LOGINFO)
        r = requests.get(url, headers=headers, timeout=10)
        
        if r.status_code == 200:
            data = r.json()
            sources = data.get('sources', [])
            
            # On cherche le flux de type HLS (m3u8)
            # Priorité au format application/x-mpegURL
            for source in sources:
                if source.get('type') == 'application/x-mpegURL' and 'src' in source:
                    stream_url = source.get('src')
                    xbmc.log(f"TQ_DEBUG: Succès ! Flux trouvé : {stream_url[:60]}...", xbmc.LOGINFO)
                    return stream_url
                    
        xbmc.log(f"TQ_DEBUG: Erreur Brightcove {r.status_code} : {r.text}", xbmc.LOGERROR)
        return None
        
    except Exception as e:
        xbmc.log(f"TQ_DEBUG: Erreur dans le resolver : {str(e)}", xbmc.LOGERROR)
        return None