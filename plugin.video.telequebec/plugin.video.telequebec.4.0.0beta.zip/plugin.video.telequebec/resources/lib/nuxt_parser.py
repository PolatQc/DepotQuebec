# -*- coding: utf-8 -*-
"""
Utilitaires pour analyser les payloads .data (format Nuxt "devalue") de
telequebec.tv. Isolé de telequebec_api.py pour garder ce dernier concentré
sur les appels réseau plutôt que sur l'analyse des données brutes.
"""

BADGES = {"Nouveauté", "Exclusivité"}
BAD_TOKENS = {"link", "SEASON", "COLLECTION", "productType", "imageAlt", "",
              "shortSummary", "brand", "rating", "promotionalLabel"}


def parse_section_items(data):
    """
    Extrait la liste des fiches (émissions/séries/films) d'un payload de
    section, sous la forme [{'label', 'path', 'thumb', 'plot'}, ...].
    """
    results = []
    seen_links = set()

    link_indices = [
        i for i, item in enumerate(data)
        if isinstance(item, str) and item.startswith('/contenu/') and '/saison/' not in item
    ]

    for pos, idx in enumerate(link_indices):
        link = data[idx]
        if link in seen_links:
            continue

        # La fenêtre de recherche s'arrête toujours à la prochaine fiche,
        # jamais plus loin, pour éviter de récupérer le titre/résumé
        # d'une autre émission quand celle-ci n'a pas de classement.
        window_end = link_indices[pos + 1] if pos + 1 < len(link_indices) else min(len(data), idx + 25)

        thumb = ""
        for j in range(idx, window_end):
            val = data[j]
            if isinstance(val, str) and "imageproxy" in val and not thumb:
                thumb = val

        # 1. La position directe (le mot juste avant le lien) est fiable
        # sauf quand c'est un jeton de schéma du format Nuxt (devalue).
        title = data[idx - 1] if idx > 0 and isinstance(data[idx - 1], str) else None
        if title is None or title in BAD_TOKENS or title.isdigit():
            title = None

            # 2. Repli : chercher une chaîne d'accessibilité avec "Classement"
            # (la plus fiable quand présente), bornée à la fiche suivante.
            for j in range(idx, window_end):
                val = data[j]
                if isinstance(val, str) and "Classement" in val and ". " in val:
                    candidate = _extract_title(val)
                    if candidate:
                        title = candidate
                        break

            # 3. Dernier recours : n'importe quelle phrase "Titre. ..."
            # dans la fenêtre bornée (émissions sans classement affiché).
            if not title:
                for j in range(idx, window_end):
                    val = data[j]
                    if isinstance(val, str) and ". " in val:
                        candidate = _extract_title(val)
                        if candidate:
                            title = candidate
                            break

        if not title:
            continue

        seen_links.add(link)
        results.append({'label': title, 'path': link, 'thumb': thumb, 'plot': ""})

    return results


def _extract_title(text):
    """Extrait le titre au début d'une chaîne 'Titre. reste du texte...'."""
    parts = text.split(". ")
    candidate = parts[0].strip()
    if candidate in BADGES and len(parts) > 1:
        candidate = parts[1].strip()
    if candidate and not candidate.isdigit() and candidate not in BAD_TOKENS:
        return candidate
    return None


def detect_season_from_data(data_initial, product_slug, fallback="1"):
    """Devine la saison à partir des liens /regarder/slug/N/... du payload."""
    for item in data_initial or []:
        if isinstance(item, str) and f"/regarder/{product_slug}/" in item:
            parts = item.split('/')
            if len(parts) > 3 and parts[3].isdigit():
                return parts[3]
    return fallback


def parse_episodes(data_initial, product_slug, detected_season):
    """
    Extrait, pour une saison donnée, l'ensemble des vrais numéros d'épisode
    ainsi que les banques d'images/mediaId/résumés associées.
    Retourne (episode_numbers, image_bank, id_bank, plot_bank).
    """
    image_bank = {}
    id_bank = {}
    plot_bank = {}
    episode_numbers = set()

    if not data_initial:
        return episode_numbers, image_bank, id_bank, plot_bank

    target_prefix = f"/{product_slug}/{detected_season}/"

    for i, item in enumerate(data_initial):
        if not (isinstance(item, str) and target_prefix in item):
            continue

        current_path = item.split('?')[0].rstrip('/')

        for j in range(max(0, i - 150), min(len(data_initial), i + 150)):
            val = data_initial[j]
            if isinstance(val, str):
                if "imageproxy" in val and current_path not in image_bank:
                    image_bank[current_path] = val
                elif len(val) > 70 and "http" not in val and current_path not in plot_bank:
                    plot_bank[current_path] = val

            # On ne prend QUE les IDs de 13 chiffres (les IDs de 5-8 chiffres
            # ne sont pas des identifiants vidéo valides).
            if isinstance(val, (int, str)) and str(val).isdigit():
                s_val = str(val)
                if len(s_val) >= 12 and current_path not in id_bank:
                    id_bank[current_path] = s_val

        last_segment = current_path.split('/')[-1]
        if last_segment.isdigit():
            episode_numbers.add(int(last_segment))

    return episode_numbers, image_bank, id_bank, plot_bank


def find_media_id(data, index):
    for j in range(max(0, index - 10), min(len(data), index + 100)):
        val = data[j]
        if isinstance(val, (int, str)) and str(val).isdigit() and len(str(val)) >= 5:
            return str(val)
    return None


def find_image(data, index):
    for j in range(index, min(len(data), index + 40)):
        if isinstance(data[j], str) and "imageproxy" in data[j]:
            return data[j]
    return ""
