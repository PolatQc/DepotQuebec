import requests
import json
import xbmc
import urllib.parse
import re

from .nuxt_parser import (
    parse_section_items,
    parse_episodes,
    detect_season_from_data,
    find_media_id,
    find_image,
)


class TeleQuebecAPI:
    def __init__(self):
        self.base_url = "https://telequebec.tv"
        self.graphql_url = "https://api.pc-cms.tele.quebec/graphql"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Origin": "https://telequebec.tv",
            "Referer": "https://telequebec.tv/"
        }

    def _get_data(self, path):
        clean_path = path.replace('.data', '')
        if not clean_path.startswith('/'): clean_path = '/' + clean_path
        url = f"{self.base_url}{clean_path}.data"
        try:
            r = requests.get(url, headers=self.headers, timeout=10)
            return json.loads(r.text) if r.status_code == 200 else []
        except: return []

    def get_section(self, path):
        data = self._get_data(f"/section/{path}")
        return parse_section_items(data)

    def get_seasons(self, path):
        product_slug = path.split('/')[-1].replace('.data', '')
        seasons = set()

        # On utilise GraphQL pour voir ce que le serveur "possède" comme saisons
        query = {
            "query": """
            query getProductSaisons($slug: String!) {
              productByRootProductSlug(rootProductSlug: $slug) {
                seasons {
                  seasonNumber
                }
              }
            }
            """,
            "variables": {"slug": product_slug}
        }

        try:
            r = requests.post(self.graphql_url, json=query, headers=self.headers, timeout=10)
            if r.status_code == 200:
                data = r.json()
                saisons_list = data.get('data', {}).get('productByRootProductSlug', {}).get('seasons', [])
                for s in saisons_list:
                    num = s.get('seasonNumber')
                    if num is not None:
                        seasons.add(str(num))
        except:
            pass

        # Si GraphQL ne donne rien, on garde ton ancienne détection
        if not seasons:
            data_initial = self._get_data(path)
            if data_initial:
                for item in data_initial:
                    if isinstance(item, str) and f"/{product_slug}/" in item:
                        parts = item.split('/')
                        if len(parts) > 3 and parts[3].isdigit():
                            seasons.add(parts[3])

        if not seasons:
            seasons.add("1")

        seasons_sorted = sorted(list(seasons), key=int, reverse=True)

        # On filtre les saisons qui n'ont en réalité aucun épisode publié
        seasons_with_content = [s for s in seasons_sorted if self._season_has_episodes(product_slug, s)]

        # Filet de sécurité : si la détection échoue pour toutes les saisons,
        # on préfère montrer la liste complète plutôt qu'un menu vide.
        return seasons_with_content if seasons_with_content else seasons_sorted

    def _season_has_episodes(self, product_slug, season):
        current_data_path = f"/contenu/{product_slug}/saison/{season}"
        data = self._get_data(current_data_path)
        if not data:
            data = self._get_data(f"/contenu/{product_slug}")

        target_prefix = f"/{product_slug}/{season}/"
        for item in data:
            if isinstance(item, str) and target_prefix in item:
                return True
        return False

    def get_episodes(self, path, season=None):
        product_slug = path.split('/')[-1].replace('.data', '')

        current_data_path = path
        if season and season != "None":
            current_data_path = f"/contenu/{product_slug}/saison/{season}"

        data_initial = self._get_data(current_data_path)
        if not data_initial:
            data_initial = self._get_data(path)

        detected_season = season if season else detect_season_from_data(data_initial, product_slug, fallback="1")

        episode_numbers, image_bank, id_bank, plot_bank = parse_episodes(data_initial, product_slug, detected_season)

        # Filet de sécurité : si aucun numéro d'épisode n'a pu être détecté,
        # on retombe sur l'ancien comportement (1 à 30) plutôt que de ne rien afficher.
        if not episode_numbers:
            episode_numbers = set(range(1, 31))

        all_episodes = []
        for i in sorted(episode_numbers):
            real_path = f"/regarder/{product_slug}/{detected_season}/{i}"
            all_episodes.append({
                'label': f"Épisode {i}",
                'path': real_path,
                'mediaId': id_bank.get(real_path, ""),
                'thumb': image_bank.get(real_path, ""),
                'plot': plot_bank.get(real_path, "Détails disponibles au lancement.")
            })

        all_episodes.reverse()
        return all_episodes

    def _find_media_id(self, data, index):
        return find_media_id(data, index)

    def _find_image(self, data, index):
        return find_image(data, index)