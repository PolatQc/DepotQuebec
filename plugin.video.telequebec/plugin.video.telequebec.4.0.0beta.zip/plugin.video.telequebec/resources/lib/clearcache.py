# -*- coding: utf-8 -*-
# version 4.0.0 - Compatible Kodi 21 (Python 3)

import os
import sys
import xbmc
import xbmcgui
import xbmcvfs
from xbmcaddon import Addon

addon = Addon('plugin.video.telequebec')

# Utilisation de xbmcvfs.translatePath sans décodage (Python 3 est déjà en unicode)
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_cache_basedir = os.path.join(addon_path, ".cache")

# Vérification des arguments (sys.argv[1] est l'argument "full" envoyé par settings.xml)
if len(sys.argv) > 1 and sys.argv[1].lower() == "full":
    # Utilisation de xbmc.log au lieu de print pour voir les infos dans le journal Kodi
    xbmc.log("[" + addon.getAddonInfo('name') + "] deleting full cache", xbmc.LOGINFO)
    
    if os.path.exists(addon_cache_basedir):
        for root, dirs, files in os.walk(addon_cache_basedir):
            for file in files:
                # Suppression via xbmcvfs pour une meilleure compatibilité système
                xbmcvfs.delete(os.path.join(root, file))
        
        # Affichage du message de confirmation
        xbmcgui.Dialog().ok(
            addon.getAddonInfo('name'), 
            "Cache vidé", 
            "Tous les fichiers temporaires ont été supprimés."
        )