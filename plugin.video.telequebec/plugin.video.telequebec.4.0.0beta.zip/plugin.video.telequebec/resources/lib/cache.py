# -*- coding: utf-8 -*-
# version 4.0.0 - Compatible Kodi 21 (Python 3)

import xbmcaddon, os, xbmc, time, sys, traceback
import xbmcvfs
from hashlib import md5 as _hash  # En Python 3, hashlib est le standard

# Import local - On assume que log.py et html.py sont dans le même dossier
from .log import log
from . import html

ADDON = xbmcaddon.Addon()

# Utilisation de xbmcvfs.translatePath et suppression du .decode()
ADDON_CACHE_BASEDIR = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('path')), ".cache")

# Récupération sécurisée du TTL (Time To Live)
try:
    cache_setting = ADDON.getSetting('CacheTTL')
    # On remplace les anciennes valeurs de l'enum par des nombres réels
    ADDON_CACHE_TTL = float(cache_setting.replace("0", ".5").replace("73", "0"))
except:
    ADDON_CACHE_TTL = 24.0

if not os.path.exists(ADDON_CACHE_BASEDIR):
    os.makedirs(ADDON_CACHE_BASEDIR)

def is_cached_content_expired(last_update):
    """ Vérifie si le fichier en cache est trop vieux """
    # TTL * 3600 secondes
    return time.time() >= (last_update + (ADDON_CACHE_TTL * 3600))

def get_cached_content(path, verified=True, headers=None):
    """ Récupère le contenu localement s'il existe, sinon le télécharge """
    if headers is None:
        headers = []
    content = None
    filename = get_cached_filename(path)
    
    try:
        if os.path.exists(filename) and not is_cached_content_expired(os.path.getmtime(filename)):
            log('Lecture en CACHE du contenu suivant : ' + path)
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
        else:
            log('Lecture en LIGNE du contenu suivant : ' + path)
            content = html.get_url_txt(path, verified, headers)
            
            if content and len(content) > 0:
                try:
                    with open(filename, 'w', encoding='utf-8') as f:
                        f.write(content)
                except Exception as e:
                    log('Impossible d\'écrire le contenu en cache : ' + str(e))
    except Exception as e:
        log('ERREUR - Problème avec le cache pour : ' + path + " Erreur : " + str(e))
        return None
    return content

def get_cached_filename(path):
    """ Génère un nom de fichier unique basé sur l'URL """
    # En Python 3, le MD5 nécessite des bytes, on doit encoder l'URL en utf-8
    return os.path.join(ADDON_CACHE_BASEDIR, _hash(path.encode('utf-8')).hexdigest())