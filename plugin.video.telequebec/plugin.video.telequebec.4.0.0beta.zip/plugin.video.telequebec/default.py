import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import requests
import re
import unicodedata
from resources.lib.telequebec_api import TeleQuebecAPI
from resources.lib.resolver import get_m3u8_url

api = TeleQuebecAPI()
handle = int(sys.argv[1])

def sort_key_sans_accents(label):
    """Trie 'Épique' avec les E plutôt qu'à la fin, en ignorant les accents
    uniquement pour la comparaison (l'affichage garde les accents)."""
    normalized = unicodedata.normalize('NFKD', label)
    stripped = ''.join(c for c in normalized if not unicodedata.combining(c))
    return stripped.lower()

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if not action:
        menu = [
            ("Émissions", "emissions"),
            ("Séries", "series"),
            ("Films", "films"),
            ("Documentaires", "documentaires")
        ]
        for name, slug in menu:
            li = xbmcgui.ListItem(label=name)
            url = f"{sys.argv[0]}?action=list_section&path={slug}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
        xbmcplugin.endOfDirectory(handle)

    elif action == 'list_section':
        path = params.get('path')
        items = api.get_section(path)
        items.sort(key=lambda x: sort_key_sans_accents(x['label']))

        for item in items:
            li = xbmcgui.ListItem(label=item['label'])
            li.setArt({'thumb': item['thumb'], 'icon': item['thumb']})
            # --- MODIFICATION ICI : On pointe vers list_seasons au lieu de list_episodes ---
            url = f"{sys.argv[0]}?action=list_seasons&path={item['path']}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
            
        xbmcplugin.endOfDirectory(handle)

    # --- NOUVELLE ACTION À AJOUTER ---
    elif action == 'list_seasons':
        path = params.get('path')
        seasons = api.get_seasons(path)
        # AJOUTE CETTE LIGNE POUR TESTER :
        xbmc.log(f"TQ_DEBUG: Saisons trouvees pour {path} : {str(seasons)}", xbmc.LOGINFO)

        for s in seasons:
            # ... reste du code
            li = xbmcgui.ListItem(label=f"Saison {s}")
            # On passe le path de l'émission ET la saison choisie
            url = f"{sys.argv[0]}?action=list_episodes&path={path}&season={s}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
            
        xbmcplugin.endOfDirectory(handle)

    elif action == 'list_episodes':
        xbmcplugin.setContent(handle, 'episodes')
        path = params.get('path')
        # On récupère la saison passée dans l'URL (si elle existe)
        season = params.get('season') 
        
        # On passe 'season' à ton API qui est maintenant prête à la recevoir
        episodes = api.get_episodes(path, season=season)

        for ep in episodes:
            li = xbmcgui.ListItem(label=ep['label'])
            li.setArt({'thumb': ep['thumb']})
            
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(ep['label'])
            info_tag.setPlot(ep['plot'])
            
            li.setProperty('IsPlayable', 'true')
            url = f"{sys.argv[0]}?action=play&mediaId={ep['mediaId']}&path={ep['path']}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
            
        xbmcplugin.endOfDirectory(handle)

    elif action == 'play':
        path = params.get('path')
        media_id = params.get('mediaId')

        # --- LOGIQUE DE SECOURS AMÉLIORÉE ---
        if not media_id or media_id == "None" or len(str(media_id)) < 8:
            xbmc.log(f"TQ_DEBUG: ID absent ou invalide ({media_id}), tentative extraction HTML", xbmc.LOGINFO)
            
            # Tentative 1: Via le .data (si existant)
            data_episode = api._get_data(path)
            if data_episode:
                media_id = api._find_media_id(data_episode, 0)
            
            # Tentative 2: Via scan HTML direct (pour Moi j'mange)
            if not media_id or media_id == "None":
                try:
                    url_web = f"https://telequebec.tv{path}"
                    r = requests.get(url_web, timeout=10)
                    if r.status_code == 200:
                        # On cherche l'ID Brightcove de 13 chiffres dans le code source
                        found = re.findall(r'\"referenceId\":\"(\d{13})\"', r.text)
                        if not found:
                            found = re.findall(r'(\d{13})', r.text)
                        
                        if found:
                            media_id = found[0]
                            xbmc.log(f"TQ_DEBUG: ID extrait du HTML: {media_id}", xbmc.LOGINFO)
                except:
                    pass

        stream_url = get_m3u8_url(media_id)
        
        if stream_url:
            play_item = xbmcgui.ListItem(path=stream_url)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/vnd.apple.mpegurl')
            play_item.setContentLookup(False)
            
            xbmcplugin.setResolvedUrl(handle, True, listitem=play_item)
        else:
            xbmc.log(f"TQ_DEBUG: Échec final de résolution pour ID {media_id}", xbmc.LOGERROR)
            xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())

if __name__ == '__main__':
    main()