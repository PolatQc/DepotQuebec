# -*- coding: utf-8 -*-
# version 3.1.0 - By CB, PLafrance & andreq
# version 3.0.0 - By CB
# version 2.0.2 - By SlySen
# version 0.2.6 - By CB
#
# pylint...: --max-line-length 120
# vim......: set expandtab
# vim......: set tabstop=4
#

import sys, xbmcgui, xbmcplugin, xbmcaddon, re, xbmc, traceback
from . import html, parse
import inputstreamhelper

if sys.version_info.major >= 3:
    # Python 3 stuff
    from urllib.parse import quote_plus, unquote, quote
    from urllib.request import Request, urlopen
    from io import StringIO as StringIO
else:
    # Python 2 stuff
    from urllib import quote_plus, unquote, quote
    from urllib2 import Request, urlopen
    from StringIO import StringIO

try:
    import json
except ImportError:
    import simplejson as json

ADDON = xbmcaddon.Addon()
BUILD_NUMBER      = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
ADDON_IMAGES_BASEPATH = ADDON.getAddonInfo('path')+'/resources/media/images/'
ADDON_FANART = ADDON.getAddonInfo('path')+'/resources/fanart.jpg'

__handle__ = int(sys.argv[1])

def ajouterItemAuMenu(items):
    for item in items:
        if item['isDir'] == True:
            ajouterRepertoire(item)
            
        else:
            ajouterVideo(item)

    if items:
        if items[0]['forceSort']  :
            xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_DATE)




def ajouterRepertoire(show):
   
    nom = show['nom']
    url = show['url']
    iconimage =show['image']
    #genreId = show['genreId']
    resume = remove_any_html_tags(show['resume'])
    fanart = show['fanart']
    filtres = show['filtres']

    if resume=='':
        resume = unquote(ADDON.getAddonInfo('id')+' v.'+ADDON.getAddonInfo('version'))

    if iconimage=='':
        iconimage = ADDON_IMAGES_BASEPATH+'default-folder.png'

    """ function docstring """
    entry_url = sys.argv[0]+"?url="+url+\
        "&mode=1"+\
        "&filters="+quote(json.dumps(filtres))
  
    is_it_ok = True
    #liz = xbmcgui.ListItem(nom,iconImage=iconimage,thumbnailImage=iconimage)
    liz = xbmcgui.ListItem(nom)

    liz.setArt({ 'thumb' : iconimage } )
    liz.setArt({ 'poster' : iconimage } )
    liz.setArt({ 'fanart' : fanart } )

    liz.setInfo(\
        type="Video",\
        infoLabels={\
            "Title": nom,\
            "plot":resume
        }\
    )
    

    is_it_ok = xbmcplugin.addDirectoryItem(handle=__handle__, url=entry_url, listitem=liz, isFolder=True)

    return is_it_ok

def ajouterVideo(show):
    name = show['nom']
    the_url = show['url']
    iconimage = show['image']
    resume = show['resume'] #remove_any_html_tags(show['resume'] +'[CR][CR]' + finDisponibilite)
    duree = None
    premiere = None
    episode = None
    saison = None

    if 'duree' in show:
        duree = show['duree']
    fanart = show['fanart']

    sourceUrl = show['sourceUrl']

    annee = "" #show['startDate'][:4]
    if 'startDate' in show:
        premiere = show['startDate']
    if 'episodeNo' in show:
        episode = show['episodeNo']
    if 'seasonNo' in show:
        saison = show['seasonNo']
    
    is_it_ok = True
    entry_url = sys.argv[0]+"?url="+quote_plus(the_url)+"&sourceUrl="+quote_plus(sourceUrl)
    print (entry_url)
    print ("URL")
    liz = xbmcgui.ListItem(remove_any_html_tags(name))

    liz.setArt({ 'poster' : iconimage } )
    liz.setArt({ 'thumb' : iconimage } )
    liz.setArt({ 'fanart' : fanart } )

    liz.setInfo(\
        type="Video",\
        infoLabels={\
            "Title":remove_any_html_tags(name),\
            "Plot":remove_any_html_tags(resume, False),\
            "Duration":duree,\
            "Year":annee,\
            "Premiered":premiere,\
            "Episode":episode,\
            "Season":saison}\
    )
    liz.addContextMenuItems([('Informations', 'Action(Info)')])
    liz.setProperty('IsPlayable', 'true')

    is_it_ok = xbmcplugin.addDirectoryItem(handle=__handle__, url=entry_url, listitem=liz, isFolder=False)
    return is_it_ok

RE_HTML_TAGS = re.compile(r'<[^>]+>')
RE_AFTER_CR = re.compile(r'\n.*')

def jouer_video(source_url):
    """ function docstring """
    try:
        check_for_internet_connection()
        uri = None
        
        log("--media_uid--")
        log(source_url)
        video_id = ''

        if source_url == 'direct':
            video_id = '2013891'
        else:
            graph_content = '{"operationName":"axisContent","variables":{"id":"'+source_url+'","subscriptions":["CANAL_D","CANAL_VIE","INVESTIGATION","NOOVO","VRAK","Z"],"maturity":"ADULT","language":"FRENCH","authenticationState":"UNAUTH","playbackLanguage":"FRENCH"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"'+html.hash_256(source_url)+'"}},"query":"query axisContent($id: ID!, $subscriptions: [Subscription]!, $maturity: Maturity!, $language: Language!, $authenticationState: AuthenticationState!, $playbackLanguage: PlaybackLanguage!) @uaContext(subscriptions: $subscriptions, maturity: $maturity, language: $language, authenticationState: $authenticationState, playbackLanguage: $playbackLanguage) {\n  axisContent(id: $id) {\n    axisId\n    id\n    path\n    title\n    duration\n    agvotCode\n    description\n    episodeNumber\n    seasonNumber\n    pathSegment\n    genres {\n      name\n      __typename\n    }\n    axisMedia {\n      id\n      title\n      __typename\n    }\n    adUnit {\n      heroBrand\n      analyticsTitle\n      pageType\n      product\n      revShare\n      title\n      keyValue {\n        adTarget\n        contentType\n        mediaType\n        pageTitle\n        revShare\n        __typename\n      }\n      __typename\n    }\n    authConstraints {\n      authRequired\n      language\n      startDate\n      endDate\n      __typename\n    }\n    axisPlaybackLanguages {\n      destinationCode\n      language\n      duration\n      __typename\n    }\n    originalSpokenLanguage\n    ogFields {\n      ogDescription\n      ogImages {\n        url\n        __typename\n      }\n      ogTitle\n      __typename\n    }\n    seoFields {\n      seoDescription\n      seoTitle\n      seoKeywords\n      __typename\n    }\n    flag {\n      title\n      label\n      __typename\n    }\n    posterImages: images(formats: POSTER) {\n      url\n      __typename\n    }\n    broadcastDate\n    expiresOn\n    startsOn\n    keywords\n    __typename\n  }\n}\n"}'
            media_response = html.get_graphql_data(graph_content)
            video_id = str(media_response['data']['axisContent']['axisId'])

        log(video_id)

        package = html.get_url_txt('https://capi.9c9media.com/destinations/noovo_hub/platforms/desktop/contents/'+video_id+'/contentpackages?$lang=fr&$include=[duration]')
        json_package = json.loads(package)
        package_id = str(json_package['Items'][0]['Id'])

        uri = 'https://capi.9c9media.com/destinations/noovo_hub/platforms/desktop/playback/contents/'+video_id+'/contentPackages/'+package_id+'/manifest.mpd?action=reference&ssl=true&filter=fe&did=69ddab77a1556e160768ac18&mca=false&uhd=false&mcv=false&hd=true&tpt=true&mta=true&stt=false'
        
        uri = html.get_url_txt(uri)
        if isinstance(uri, bytes):
            uri = uri.decode('utf-8').strip()

        log('URI obtenue: ' + uri)
        
        # ÉTAPE 1 : Vérifier/Installer Widevine AVANT de créer l'item
        log('Vérification de Widevine CDM...')
        is_helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
        
        if not is_helper.check_inputstream():
            log('ERREUR: Widevine CDM n\'a pas pu être installé')
            xbmc.executebuiltin('Notification(Erreur Widevine,Impossible d\'installer Widevine CDM. Redémarrez Kodi.,8000)')
            return
        
        log('Widevine CDM OK')
        
        # ÉTAPE 2 : Créer l'item de lecture avec les propriétés correctes
        listitem = xbmcgui.ListItem(path=uri)
        
        # IMPORTANT: Utiliser les propriétés retournées par inputstreamhelper
        listitem.setProperty('inputstream', is_helper.inputstream_addon)
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        listitem.setMimeType('application/dash+xml')
        listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        listitem.setProperty('inputstream.adaptive.license_key', 'https://license.9c9media.ca/widevine||R{SSM}|')
        
        log('Propriétés InputStreamHelper configurées')
        log('Tentative de lecture avec Widevine...')
        
        # ÉTAPE 3 : Lancer la lecture
        xbmcplugin.setResolvedUrl(__handle__, True, listitem)
        log('Lecture lancée avec URI: ' + uri)
        
    except Exception as e:
        log('ERREUR lecture: ' + str(e))
        log('Traceback: ' + traceback.format_exc())
        xbmc.executebuiltin('Notification(Erreur,Impossible de lancer la vidéo,5000)')
        return

def check_for_internet_connection():
    """ function docstring """
    if ADDON.getSetting('NetworkDetection') == 'false':
        return
    return

def remove_any_html_tags(text, crlf=True):
    """ function docstring """
    text = RE_HTML_TAGS.sub('', parse.pyStr(text, True))
    text = text.lstrip()
    if crlf == True:
        text = RE_AFTER_CR.sub('', parse.pyStr(text, True))
    return text

def obtenirMeilleurStream(pl):
    maxBW = 0
    bandWidth=None
    uri = None
    for line in pl.split('\n'):
        if re.search('#EXT-X',line):
            bandWidth=None
            try:
                match  = re.search(r'bandwidth=(\d+)',line)
                bandWidth = int(match.group(1))
            except :
                bandWidth=None
        elif line.startswith('http'):
            if bandWidth!=None:
                if bandWidth>maxBW:
                    maxBW = bandWidth
                    uri = line
    return uri

def log(msg):
    """ function docstring """
    if xbmcaddon.Addon().getSetting('DebugMode') == 'true':
        xbmc.log('[%s - DEBUG]: %s' % (xbmcaddon.Addon().getAddonInfo('name'), msg))
